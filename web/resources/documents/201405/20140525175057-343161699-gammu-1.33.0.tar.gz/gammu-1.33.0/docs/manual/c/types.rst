Types
=====

.. doxygentypedef:: gboolean

