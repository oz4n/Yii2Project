Miscellaneous
=============

.. doxygenfunction:: GetLine
.. doxygenfunction:: GetGammuVersion
.. doxygenfunction:: GetCompiler
.. doxygenfunction:: GetOS
.. doxygenfunction:: GetGammuLocalePath
.. doxygenfunction:: GSM_InitLocales
.. doxygenfunction:: EncodeHexBin
.. doxygenfunction:: GSM_IsNewerVersion
