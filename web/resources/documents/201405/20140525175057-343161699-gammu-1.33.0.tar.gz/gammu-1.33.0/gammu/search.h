extern void SearchPhone(int argc, char *argv[]);
