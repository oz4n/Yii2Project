
extern void bluez_detect(void);
