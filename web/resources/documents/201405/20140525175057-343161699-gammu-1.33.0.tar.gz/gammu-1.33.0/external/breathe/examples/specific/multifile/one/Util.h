

namespace test {

typedef float MyFloat;

void TestFunc() {};

}

