

Embedded Rst
============


.. doxygenindex:: 
   :path: ../examples/specific/rst/xml
   :no-link:

