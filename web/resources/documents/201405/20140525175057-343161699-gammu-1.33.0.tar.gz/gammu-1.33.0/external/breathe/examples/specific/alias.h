
/**
 * Foo frob routine.
 * @sideeffect Frobs any foos.
 */
void frob_foos(void);

