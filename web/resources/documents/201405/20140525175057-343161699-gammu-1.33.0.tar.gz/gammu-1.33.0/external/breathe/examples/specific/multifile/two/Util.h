
namespace test {

typedef int MyInt;

struct TestStruct {};

}

