
Specific Examples Test Suite
============================


Typedef Examples
----------------

.. doxygenindex::
   :path: ../examples/specific/typedef/xml
   :no-link:


Namespaced Function Examples
----------------------------

.. doxygenfunction:: testnamespace::NamespacedClassTest::function
   :path: ../examples/specific/class/xml
   :no-link:

.. doxygenfunction:: testnamespace::ClassTest::function
   :path: ../examples/specific/class/xml
   :no-link:

.. doxygenfunction:: testnamespace::ClassTest::anotherFunction
   :path: ../examples/specific/class/xml
   :no-link:

.. doxygenfunction:: ClassTest::function
   :path: ../examples/specific/class/xml
   :no-link:

.. doxygenfunction:: ClassTest::anotherFunction
   :path: ../examples/specific/class/xml
   :no-link:

Alias Example
-------------

.. doxygenfunction:: frob_foos
   :path: ../examples/specific/alias/xml
   :no-link:

Fixed Width Font
----------------

.. doxygenclass:: Out
   :path: ../examples/specific/fixedwidthfont/xml
   :members:
   :no-link:


